This Project is based on a logisim software simulating a 24hour digital clock using basic decoders,counters,SSD(7 segment displays).
